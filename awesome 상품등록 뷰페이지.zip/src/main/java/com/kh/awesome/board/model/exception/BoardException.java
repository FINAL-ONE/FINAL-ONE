package com.kh.awesome.board.model.exception;

public class BoardException extends RuntimeException{
	public BoardException(String msg) {
		super(msg);
	}
}
