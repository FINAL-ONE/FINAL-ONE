package com.kh.awesome.member.model.exception;

public class MemberException extends RuntimeException{
	public MemberException(String msg) {
		super(msg);
	}
}