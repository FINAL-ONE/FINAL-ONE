package com.kh.awesome.shop.model.exception;

public class ShopException extends RuntimeException{
	public ShopException(String msg) {
		super(msg);
	}

}
