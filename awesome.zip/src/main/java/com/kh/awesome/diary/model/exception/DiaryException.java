package com.kh.awesome.diary.model.exception;

public class DiaryException extends RuntimeException{
	public DiaryException(String msg) {
		super(msg);
	}
}