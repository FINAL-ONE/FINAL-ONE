package com.kh.awesome.diary.model.service;

public interface DiaryService {

}
