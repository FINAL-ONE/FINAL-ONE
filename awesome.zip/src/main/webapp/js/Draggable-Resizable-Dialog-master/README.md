# Draggable + Resizable Dialog

Pure Javascript draggable and resizable dialog boxes  
[Demo](https://zulns.github.io/Draggable-Resizable-Dialog/)
