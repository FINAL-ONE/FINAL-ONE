# Switch 
A minimalist input switch in pure CSS.
