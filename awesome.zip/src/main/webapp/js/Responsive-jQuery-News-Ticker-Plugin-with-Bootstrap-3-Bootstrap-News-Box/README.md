jQuery-bootstrap
================

<p>A simple, lightweight jQuery bootstrap plugin to easy scroll your news.</p>

<ul>
	<ol>Responsive</ol>
	<ol>lightweight</ol>
	<ol>easy to use</ol>
	<ol>scroll any news format in up/down direction</ol>
	<ol>...</ol>
</ul>

<p>Available Options:</p>
<pre>
	$.fn.bootstrapNews.options = {
        newsPerPage: 4, 
        navigation: true,
        autoplay: true,
        direction:'up',
        animationSpeed: 'normal',
        newsTickerInterval: 4000, //4 secs
        pauseOnHover: true,
        onStop: null,
        onPause: null,
        onReset: null,
        onPrev: null,
        onNext: null,
        onToDo: null
    };
</pre> 

<h2>Example</h2>
<p>Please, check the demo.html</p>
