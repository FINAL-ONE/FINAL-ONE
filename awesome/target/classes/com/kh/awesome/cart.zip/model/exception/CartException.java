package com.kh.awesome.cart.model.exception;

public class CartException extends RuntimeException{
	public CartException(String msg) {
		super(msg);
	}

}
