package com.kh.awesome.cart.model.vo;

import java.io.Serializable;

public class CartList implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -4857349693191579439L;
	private int cartNum;	// 카트 번호 시퀀스 넘버
	private int gid;		// 상품 번호
	private int mid;		// 유저 
	private int count;		// 상품 수량
	
	
	private String goodsName;	// 상품 이름
	private int goodsPrice;		// 상품 가격
	private String filePath;	// 이미지
	private String soldout;		// 품절되었는지??
	
	public CartList() {
		
	}

	public CartList(int cartNum, int gid, int mid, int count, String goodsName, int goodsPrice, String filePath,
			String soldout) {
		super();
		this.cartNum = cartNum;
		this.gid = gid;
		this.mid = mid;
		this.count = count;
		this.goodsName = goodsName;
		this.goodsPrice = goodsPrice;
		this.filePath = filePath;
		this.soldout = soldout;
	}

	public int getCartNum() {
		return cartNum;
	}

	public void setCartNum(int cartNum) {
		this.cartNum = cartNum;
	}

	public int getGid() {
		return gid;
	}

	public void setGid(int gid) {
		this.gid = gid;
	}

	public int getMid() {
		return mid;
	}

	public void setMid(int mid) {
		this.mid = mid;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public String getGoodsName() {
		return goodsName;
	}

	public void setGoodsName(String goodsName) {
		this.goodsName = goodsName;
	}

	public int getGoodsPrice() {
		return goodsPrice;
	}

	public void setGoodsPrice(int goodsPrice) {
		this.goodsPrice = goodsPrice;
	}

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	public String getSoldout() {
		return soldout;
	}

	public void setSoldout(String soldout) {
		this.soldout = soldout;
	}

	@Override
	public String toString() {
		return "CartList [cartNum=" + cartNum + ", gid=" + gid + ", mid=" + mid + ", count=" + count + ", goodsName="
				+ goodsName + ", goodsPrice=" + goodsPrice + ", filePath=" + filePath + ", soldout=" + soldout + "]";
	}
	
	
	
	
}
